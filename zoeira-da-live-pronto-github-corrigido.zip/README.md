# Zoeira da Live – Sorteador de Frases

Aplicativo web/PWA para sortear frases e zoeiras durante lives.

## Publicar gratuitamente no GitHub Pages

Este projeto já está configurado para o repositório **`zoeira-da-live`** e para a conta GitHub Pages no formato:

`https://SEU-USUARIO.github.io/zoeira-da-live/`

1. Crie um repositório **público** chamado `zoeira-da-live` no GitHub.
2. Envie todos os arquivos e pastas deste ZIP para a raiz do repositório (não envie a pasta ZIP dentro do repositório).
3. No GitHub, abra **Settings → Pages**.
4. Em **Build and deployment → Source**, selecione **GitHub Actions**.
5. Abra a aba **Actions** e aguarde o fluxo **Publicar no GitHub Pages** terminar com sucesso.
6. Acesse `https://SEU-USUARIO.github.io/zoeira-da-live/`, substituindo `SEU-USUARIO` pelo seu nome de usuário do GitHub.

Depois da primeira publicação, cada novo envio para a branch `main` dispara uma atualização automática.

## Executar localmente

Requer Node.js 20.19+ (recomendado Node 22).

```bash
npm install
npm run dev
```

Para gerar a versão de produção:

```bash
npm run build
```

Os arquivos finais ficam na pasta `dist/`.

## Observações

- GitHub Pages hospeda a interface estática; não executa servidor Node/Express nem banco de dados.
- Dados salvos no armazenamento local do navegador (`localStorage`) ficam naquele navegador/dispositivo e não são sincronizados automaticamente com outros usuários.
- Se futuramente adicionar uma API ou segredo privado, não coloque chaves secretas no código frontend nem em variáveis `VITE_*`: elas ficam visíveis para quem acessar o aplicativo.
