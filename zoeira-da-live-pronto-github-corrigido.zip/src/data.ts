export type SectorId =
  | 'maxima'
  | 'leve'
  | 'basica'
  | 'carinhosa'
  | 'elogio'
  | 'epico'
  | 'lendario';

export interface Sector {
  id: SectorId;
  name: string;
  desc: string;
  emoji: string;
  color: string; // tailwind gradient classes
}

export const SECTORS: Sector[] = [
  { id: 'maxima', name: 'Zoeira Máxima', desc: 'Nome simples • Homem', emoji: '🔥', color: 'from-red-600 to-orange-500' },
  { id: 'leve', name: 'Zoeira de Boa', desc: 'Nome simples • Mulher', emoji: '😏', color: 'from-pink-500 to-fuchsia-500' },
  { id: 'basica', name: 'Zoeira Básica', desc: 'Presentes pequenos', emoji: '😜', color: 'from-amber-500 to-yellow-400' },
  { id: 'carinhosa', name: 'Zoeira Carinhosa', desc: 'Presentes intermediários', emoji: '🫶', color: 'from-rose-500 to-pink-400' },
  { id: 'elogio', name: 'Elogio dos Bons', desc: 'Galáxia', emoji: '🌌', color: 'from-indigo-500 to-violet-500' },
  { id: 'epico', name: 'Elogio Épico', desc: 'Mini Leão e Leão', emoji: '🦁', color: 'from-orange-500 to-amber-400' },
  { id: 'lendario', name: 'Elogio Lendário', desc: 'TikTok Universe', emoji: '👑', color: 'from-cyan-400 to-fuchsia-500' },
];

export interface Gift {
  id: string;
  name: string;
  emoji: string;
  coins?: string;
  sector: SectorId;
  group: string;
}

export const GIFTS: Gift[] = [
  { id: 'rosa', name: 'Rosa', emoji: '🌹', coins: '1', sector: 'basica', group: 'Pequenos' },
  { id: 'gg', name: 'GG', emoji: '🎮', coins: '1', sector: 'basica', group: 'Pequenos' },
  { id: 'sorvete', name: 'Casquinha', emoji: '🍦', coins: '1', sector: 'basica', group: 'Pequenos' },
  { id: 'panda', name: 'Panda', emoji: '🐼', coins: '5', sector: 'basica', group: 'Pequenos' },
  { id: 'coracao', name: 'Mão c/ Coração', emoji: '🫶', coins: '100', sector: 'carinhosa', group: 'Intermediários' },
  { id: 'galaxia', name: 'Galáxia', emoji: '🌌', coins: '1.000', sector: 'elogio', group: 'Intermediários' },
  { id: 'minileao', name: 'Mini Leão', emoji: '🦁', sector: 'epico', group: 'Grandes' },
  { id: 'leao', name: 'Leão', emoji: '👑', coins: '29.999', sector: 'epico', group: 'Grandes' },
  { id: 'universe', name: 'TikTok Universe', emoji: '🪐', coins: '44.999', sector: 'lendario', group: 'Grandes' },
];

// Use {nome} onde o nome da pessoa deve aparecer
export const DEFAULT_PHRASES: Record<SectorId, string[]> = {
  maxima: [
    '{nome}, tem cara de quem fala "já tô chegando" ainda deitado na cama',
    '{nome}, o chulé chegou na live antes de você',
    '{nome}, seu Wi-Fi é igual seu futuro, não conecta em lugar nenhum',
    '{nome}, parece que foi montado com as peças que sobraram',
    '{nome}, veio de graça e ainda reclama do sinal',
    '{nome}, você é a prova de que o Wi-Fi de Deus cai às vezes',
    '{nome}, o espelho te vê e pede demissão',
    '{nome}, já nasceu com cara de "vou só dar uma olhadinha" e ficou 4 horas',
    '{nome}, seu cheiro é tão forte que o pombo mudou de praça',
    '{nome}, tem a coragem de um leão e o cérebro de um pão de forma',
    '{nome}, manda áudio de 7 minutos pra falar "oi"',
    '{nome}, parece que carrega 1% de bateria na vida inteira',
    '{nome}, aposto que ronca e acorda os vizinhos do prédio ao lado',
    '{nome}, o único exercício que você faz é pular a parte importante do vídeo',
    '{nome}, chegou na live igual boleto, ninguém queria mas apareceu',
  ],
  leve: [
    '{nome}, chegou e já tá roubando a cena, mas ainda tem que aprender a dar presente 😏',
    '{nome}, só comenta e não manda nem uma rosa, hein? 🌹',
    '{nome}, dizem que é tímida, mas o comentário tá cheio de atitude',
    '{nome}, bonita demais pra ficar só olhando a live de graça',
    '{nome}, já pode abrir o perfil de curiosa oficial da live 👀',
    '{nome}, está aqui pra ver a live ou pra dar like e sumir?',
    '{nome}, aposto que demora 3 horas pra escolher a roupa e sai com a primeira',
    '{nome}, aparece do nada e deixa todo mundo em silêncio 😅',
    '{nome}, seu sorriso vale mais que meu sinal de internet',
    '{nome}, vai mandar um presentinho ou vai só fazer charme?',
    '{nome}, chegou tão elegante que o chat até arrumou a postura',
    '{nome}, se demorar mais pra responder vou achar que tá no mundo da lua 🌙',
  ],
  basica: [
    '{nome}, mandou presentinho! Agora você já pode dizer que sustenta a live... com 1 moeda 😂',
    '{nome}, obrigado pelo presente, vou comprar um pão com ele (se der)',
    '{nome}, um mimo de respeito! Do tamanho de um grão de arroz, mas valeu 🍚',
    '{nome}, gastou a mesada toda nisso? Respeito, mas bora com mais!',
    '{nome}, pelo menos é o mais sincero da live, mandou o que deu 😅',
    '{nome}, o presente é pequeno, mas a intenção é grande... acho',
    '{nome}, o troco do pão virou presente, gostei da iniciativa 🥖',
    '{nome}, já é um começo! Agora falta o resto da coragem',
    '{nome}, valeu pelo mimo! A live agradece e o tio aqui também',
    '{nome}, vem com mais moedas que a live tá te esperando 💸',
  ],
  carinhosa: [
    '{nome}, olha só o generoso da live! Presente com carinho, já tô até emocionado 🥹',
    '{nome}, 100 moedas? Agora sim tá nascendo uma amizade 🫶',
    '{nome}, você é raridade, ainda existe gente de bom coração na live',
    '{nome}, tá me mimando assim vou até te dar um abraço virtual 🤗',
    '{nome}, já ganhou meu respeito e um pedacinho do meu coração 💖',
    '{nome}, tem bom gosto, bom coração e ainda manda presente. Casa comigo? 😂',
    '{nome}, pode vir sempre, a casa é sua e o chat também 🏠',
    '{nome}, bateu forte aqui no coração, só não vai embora depois do presente 😭',
  ],
  elogio: [
    '{nome}, GALÁXIA! Você é uma estrela de verdade, o chat inteiro tá aplaudindo 🌌👏',
    '{nome}, com uma galáxia dessas até meu sinal ficou melhor ✨',
    '{nome}, você é patrimônio da live, tombado e protegido 🏛️',
    '{nome}, mandou uma galáxia e ainda tem estilo, que lenda! 🌟',
    '{nome}, respeito máximo! Hoje você é VIP, tapete vermelho pra você 🎬',
    '{nome}, a galáxia brilha, mas você brilha mais ainda ⭐',
    '{nome}, pode pedir o que quiser, a live inteira tá aos seus pés',
    '{nome}, o chat inteiro vai falar de você amanhã, que presente! 🚀',
  ],
  epico: [
    '{nome}, É O REI DA JUNGLE! Leão na live, todo mundo de joelhos 🦁👑',
    '{nome}, você acabou de salvar a minha live, te devo uma vida! 🙏',
    '{nome}, o chat inteiro agora te chama de patrão 🫡',
    '{nome}, que presente absurdo! Vou até tatuar seu nome (só pensando ainda)',
    '{nome}, você é lenda viva, a live vai ser contada em livros 📚',
    '{nome}, a selva toda treme com esse presente, respeito eterno 🦁🔥',
    '{nome}, digno de estátua na praça principal, você é gigante 🗿',
    '{nome}, eu nem sei o que dizer, só obrigado, patrão! 🙌',
  ],
  lendario: [
    '{nome}, TIKTOK UNIVERSE!!! Você é uma entidade, o universo inteiro parou pra te ver 🪐👑',
    '{nome}, ISSO NÃO É UM PRESENTE, É UM MILAGRE! Vou te levar pro casamento da minha prima 💍',
    '{nome}, o TikTok inteiro vai saber seu nome, você é o imperador da live! 🌍',
    '{nome}, você é meu novo melhor amigo, meu patrocinador e meu herói 😭🏆',
    '{nome}, eu vou nomear meu primeiro filho com seu nome, juro! 👶',
    '{nome}, sentem-se todos, que o dono da live chegou: {nome}! 🎤',
    '{nome}, cuidado que hoje o chão da live é de ouro por sua causa 💎',
    '{nome}, mestre supremo, deus do presente, o homem, o mito, a lenda! 🔱',
  ],
};
