import { useEffect, useRef, useState } from 'react';
import { DEFAULT_PHRASES, GIFTS, SECTORS, type Gift, type SectorId } from './data';
import PhraseEditor from './components/PhraseEditor';
import { cn } from './utils/cn';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  Volume2,
  VolumeX,
  Copy,
  Check,
  Dices,
  RotateCw,
  Search,
  MessageSquareQuote,
  History,
  Trash2,
  Gift as GiftIcon,
  X
} from 'lucide-react';

type Gender = 'homem' | 'mulher';
type Phrases = Record<SectorId, string[]>;

interface Result {
  id: number;
  text: string;
  sector: SectorId;
  name: string;
  gender: Gender;
  giftId: string | null;
  timestamp: string;
}

const STORAGE_KEY = 'zoeira-live-phrases-v1';
const CLEAR_AFTER_KEY = 'zoeira-live-clear-after';
const SOUND_ENABLED_KEY = 'zoeira-live-sound-enabled';

function loadPhrases(): Phrases {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      // remove eventuais prefixes "play:" já salvos
      const clean = raw.replace(/,?\s*play:\s*/gi, ', ');
      const parsed: Phrases = { ...DEFAULT_PHRASES, ...JSON.parse(clean) };
      return parsed;
    }
  } catch {
    /* ignore */
  }
  return DEFAULT_PHRASES;
}

function formatName(n: string) {
  return n
    .trim()
    .split(/\s+/)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');
}

// Simple Web Audio sound effects for TikTok live vibes
function playSound(type: 'scan' | 'pop' | 'epic' | 'legendary') {
  try {
    const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const now = ctx.currentTime;

    if (type === 'scan') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.linearRampToValueAtTime(0.01, now + 0.15);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === 'pop') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.1);
      gain.gain.setValueAtTime(0.18, now);
      gain.gain.linearRampToValueAtTime(0.01, now + 0.15);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === 'epic' || type === 'legendary') {
      const notes = type === 'legendary' ? [523.25, 659.25, 783.99, 1046.5] : [440, 554.37, 659.25];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const startTime = now + idx * 0.08;
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, startTime);
        gain.gain.setValueAtTime(0.15, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + 0.35);
      });
    }
  } catch {
    /* ignore audio restrictions */
  }
}

export default function App() {
  const [tab, setTab] = useState<'sortear' | 'frases'>('sortear');
  const [phrases, setPhrases] = useState<Phrases>(loadPhrases);
  const [draft, setDraft] = useState<Phrases>(phrases);
  const [showResult, setShowResult] = useState(false);
  const [storageError, setStorageError] = useState(false);
  const [name, setName] = useState('');
  const [giftId, setGiftId] = useState<string | null>(null);
  const [askGender, setAskGender] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [history, setHistory] = useState<Result[]>([]);
  const [clearAfter, setClearAfter] = useState<boolean>(() => {
    return localStorage.getItem(CLEAR_AFTER_KEY) !== 'false';
  });
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    return localStorage.getItem(SOUND_ENABLED_KEY) !== 'false';
  });
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [error, setError] = useState(false);
  const [copied, setCopied] = useState(false);

  const bag = useRef<Partial<Record<SectorId, string[]>>>({});
  const lastText = useRef<Partial<Record<SectorId, string>>>({});
  const counter = useRef(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(phrases));
      setStorageError(false);
    } catch {
      setStorageError(true);
    }
  }, [phrases]);

  // Pede ao navegador para não apagar as frases salvas quando faltar espaço
  useEffect(() => {
    navigator.storage?.persist?.().catch(() => {});
  }, []);

  const hasUnsaved = JSON.stringify(draft) !== JSON.stringify(phrases);

  useEffect(() => {
    if (!hasUnsaved) return;
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [hasUnsaved]);

  const savePhrases = () => {
    setPhrases(draft);
  };

  const closeResult = () => {
    window.speechSynthesis?.cancel();
    setIsSpeaking(false);
    setShowResult(false);
  };

  useEffect(() => {
    localStorage.setItem(CLEAR_AFTER_KEY, String(clearAfter));
  }, [clearAfter]);

  useEffect(() => {
    localStorage.setItem(SOUND_ENABLED_KEY, String(soundEnabled));
  }, [soundEnabled]);

  const gift: Gift | undefined = GIFTS.find((g) => g.id === giftId);

  const triggerCelebration = (sector: SectorId) => {
    if (sector === 'lendario') {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 },
        colors: ['#06b6d4', '#ec4899', '#f59e0b', '#8b5cf6'],
      });
      if (soundEnabled) playSound('legendary');
    } else if (sector === 'epico') {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#f97316', '#fbbf24', '#ef4444'],
      });
      if (soundEnabled) playSound('epic');
    } else {
      if (soundEnabled) playSound('pop');
    }
  };

  const draw = (rawName: string, gender: Gender, gId: string | null) => {
    const g = GIFTS.find((x) => x.id === gId);
    const sector: SectorId = g ? g.sector : gender === 'homem' ? 'maxima' : 'leve';
    const list = phrases[sector] || [];
    const nm = formatName(rawName) || 'Visitante';
    let text: string;

    if (!list.length) {
      text = `${nm}, ainda não tem frase neste setor, vai na aba Frases e adiciona! 😅`;
    } else {
      // Sorteio sem repetir: só repete uma frase depois de passar por todas do setor
      let pool = (bag.current[sector] || []).filter((p) => list.includes(p));
      if (!pool.length) {
        pool = list.length > 1 ? list.filter((p) => p !== lastText.current[sector]) : [...list];
      }
      const i = Math.floor(Math.random() * pool.length);
      const picked = pool[i];
      bag.current[sector] = pool.filter((_, k) => k !== i);
      lastText.current[sector] = picked;
      text = picked.replace(/\{nome\}/gi, nm);
    }

    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const r: Result = {
      id: ++counter.current,
      text,
      sector,
      name: rawName,
      gender,
      giftId: gId,
      timestamp: timeStr,
    };

    setResult(r);
    setShowResult(true);
    setHistory((h) => [r, ...h].slice(0, 20));
    setCopied(false);

    triggerCelebration(sector);

    if (navigator.vibrate) {
      navigator.vibrate(40);
    }
  };

  const onScan = () => {
    if (!name.trim()) {
      setError(true);
      if (navigator.vibrate) navigator.vibrate([30, 50, 30]);
      setTimeout(() => setError(false), 450);
      inputRef.current?.focus();
      return;
    }
    if (soundEnabled) playSound('scan');
    setAskGender(true);
  };

  const pickGender = (gender: Gender) => {
    setAskGender(false);
    draw(name, gender, giftId);
    if (clearAfter) {
      setName('');
      setGiftId(null);
    }
  };

  const copy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* ignore */
    }
  };

  const speak = (text: string) => {
    // Remove emojis for cleaner, more natural speech
    const cleanText = text
      .replace(/[\u{1F000}-\u{1FFFF}\u{2600}-\u{27BF}\u{1F300}-\u{1F64F}\u{1F680}-\u{1F6FF}]/gu, '')
      .trim();

    // Dentro do app do Kodular (WebView): manda o texto para o bloco TextToSpeech
    const bridge = (window as unknown as { AppInventor?: { setWebViewString?: (s: string) => void } })
      .AppInventor;
    if (bridge?.setWebViewString) {
      // limpa antes para o evento disparar mesmo se a frase for igual à anterior
      bridge.setWebViewString('');
      setTimeout(() => bridge.setWebViewString?.(cleanText), 80);
      setIsSpeaking(true);
      setTimeout(() => setIsSpeaking(false), 1200);
      return;
    }

    if (!('speechSynthesis' in window)) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(cleanText);
    u.lang = 'pt-BR';
    u.rate = 1.05;
    u.pitch = 1.02;

    u.onstart = () => setIsSpeaking(true);
    u.onend = () => setIsSpeaking(false);
    u.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(u);
  };

  const resultSector = result ? SECTORS.find((s) => s.id === result.sector) : null;
  const historyList = showResult ? history.slice(1) : history;
  const groups = ['Pequenos', 'Intermediários', 'Grandes'];

  return (
    <div className="min-h-screen bg-[#0b0714] text-white max-w-md mx-auto relative pb-24 selection:bg-fuchsia-500 selection:text-white">
      {/* Background ambient light */}
      <div className="absolute inset-x-0 top-0 h-80 bg-gradient-to-b from-fuchsia-600/25 via-purple-900/10 to-transparent pointer-events-none" />
      <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-72 h-72 bg-cyan-500/10 blur-[100px] pointer-events-none" />

      {/* Top Header */}
      <header className="relative px-4 pt-6 pb-2">
        <div className="flex items-center justify-between mb-1">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-[11px] font-semibold text-fuchsia-300">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            LIVE TIKTOK
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setSoundEnabled((s) => !s)}
              className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white/70 active:scale-95 transition cursor-pointer"
              title={soundEnabled ? 'Silenciar efeitos sonoros' : 'Ativar efeitos sonoros'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4 text-white/40" />}
            </button>
          </div>
        </div>

        <h1 className="text-3xl font-black tracking-tight text-center drop-shadow-sm">
          🎤 Zoeira da <span className="bg-gradient-to-r from-cyan-300 via-pink-400 to-fuchsia-400 bg-clip-text text-transparent">Live</span>
        </h1>
        <p className="text-xs text-white/50 text-center mt-1">
          Digite o nome, escolha o presente e sorteie a zoeira instantânea
        </p>
      </header>

      {/* Main Content Area */}
      <main className="relative px-4 mt-3">
        {tab === 'sortear' ? (
          <div className="space-y-4">
            {/* Input & Scan Section */}
            <section className="rounded-3xl bg-white/[0.04] border border-white/10 p-4 space-y-3 backdrop-blur-md shadow-2xl">
              <div className="flex items-center justify-between">
                <label className="text-[11px] uppercase tracking-wider text-white/60 font-bold flex items-center gap-1.5">
                  <Search className="w-3.5 h-3.5 text-fuchsia-400" /> Nome da pessoa na live
                </label>
                {name && (
                  <button
                    onClick={() => setName('')}
                    className="text-[11px] text-white/40 hover:text-white/70 transition flex items-center gap-0.5 cursor-pointer"
                  >
                    <X className="w-3 h-3" /> limpar
                  </button>
                )}
              </div>

              <div className="relative">
                <input
                  ref={inputRef}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && onScan()}
                  placeholder="Ex: João, Mari, Lucas..."
                  autoCapitalize="words"
                  autoComplete="off"
                  className={cn(
                    'w-full rounded-2xl bg-black/40 border-2 px-4 py-3.5 text-lg font-bold outline-none transition placeholder:text-white/20 placeholder:font-normal',
                    error
                      ? 'border-red-500 animate-shake ring-4 ring-red-500/20'
                      : 'border-white/10 focus:border-fuchsia-400/80 focus:ring-4 focus:ring-fuchsia-500/20'
                  )}
                />
              </div>

              <button
                type="button"
                onClick={onScan}
                className="w-full rounded-2xl bg-gradient-to-r from-fuchsia-600 via-pink-500 to-orange-500 py-3.5 px-4 text-lg font-black text-white shadow-lg shadow-fuchsia-600/30 active:scale-[0.98] hover:brightness-110 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-5 h-5 text-yellow-300 animate-pulse" />
                ESCANEAR
              </button>

              {gift ? (
                <div className="rounded-xl bg-white/5 border border-white/10 px-3 py-2 text-center text-xs text-white/80 flex items-center justify-center gap-2">
                  <span>Presente ativo:</span>
                  <span className="font-bold text-white flex items-center gap-1">
                    <span className="text-base">{gift.emoji}</span> {gift.name}
                  </span>
                  <button
                    onClick={() => setGiftId(null)}
                    className="ml-1 text-[11px] text-fuchsia-400 hover:text-fuchsia-300 underline cursor-pointer"
                  >
                    remover
                  </button>
                </div>
              ) : (
                <p className="text-center text-[11px] text-white/40">
                  Sem presente? Sorteia zoeira direta por Homem/Mulher
                </p>
              )}
            </section>

            {/* Gift Selector */}
            <section className="rounded-3xl bg-white/[0.04] border border-white/10 p-4 space-y-3 backdrop-blur-md">
              <div className="flex items-center justify-between">
                <h2 className="text-[11px] uppercase tracking-wider text-white/60 font-bold flex items-center gap-1.5">
                  <GiftIcon className="w-3.5 h-3.5 text-pink-400" /> Presentes do TikTok
                </h2>
                {giftId && (
                  <button
                    type="button"
                    onClick={() => setGiftId(null)}
                    className="text-xs text-fuchsia-300 hover:text-fuchsia-200 underline cursor-pointer"
                  >
                    desmarcar presente
                  </button>
                )}
              </div>

              <div className="space-y-3">
                {groups.map((grp) => (
                  <div key={grp} className="space-y-1.5">
                    <p className="text-[10px] uppercase font-bold tracking-wider text-white/40 pl-0.5">
                      {grp}
                    </p>
                    <div className="grid grid-cols-3 gap-2">
                      {GIFTS.filter((g) => g.group === grp).map((g) => {
                        const sec = SECTORS.find((s) => s.id === g.sector)!;
                        const isSelected = giftId === g.id;
                        return (
                          <button
                            key={g.id}
                            type="button"
                            onClick={() => setGiftId(isSelected ? null : g.id)}
                            className={cn(
                              'rounded-2xl border p-2.5 flex flex-col items-center gap-1 transition active:scale-95 cursor-pointer relative overflow-hidden',
                              isSelected
                                ? `bg-gradient-to-br ${sec.color} border-white/40 shadow-lg ring-2 ring-white/50`
                                : 'bg-white/5 hover:bg-white/10 border-white/10 text-white/80'
                            )}
                          >
                            <span className="text-2xl drop-shadow select-none">{g.emoji}</span>
                            <span className="text-[11px] font-bold leading-tight text-center line-clamp-1">
                              {g.name}
                            </span>
                            <span
                              className={cn(
                                'text-[10px] font-medium font-mono',
                                isSelected ? 'text-white' : 'text-white/45'
                              )}
                            >
                              {g.coins ? `🪙 ${g.coins}` : '🪙 ?'}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>

              <label className="flex items-center gap-2.5 text-xs text-white/60 pt-2 border-t border-white/5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={clearAfter}
                  onChange={(e) => setClearAfter(e.target.checked)}
                  className="accent-fuchsia-500 w-4 h-4 rounded cursor-pointer"
                />
                Limpar nome e presente após sortear
              </label>
            </section>

            {/* History Section */}
            {historyList.length > 0 && (
              <section className="rounded-3xl bg-white/[0.03] border border-white/10 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h2 className="text-[11px] uppercase tracking-wider text-white/50 font-bold flex items-center gap-1.5">
                    <History className="w-3.5 h-3.5 text-white/40" /> Frases Recentes ({historyList.length})
                  </h2>
                  <button
                    type="button"
                    onClick={() => setHistory(showResult && result ? [result] : [])}
                    className="text-xs text-white/40 hover:text-white/70 transition flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" /> limpar
                  </button>
                </div>

                <ul className="space-y-2">
                  {historyList.slice(0, 10).map((h) => {
                    const sec = SECTORS.find((s) => s.id === h.sector);
                    return (
                      <li
                        key={h.id}
                        className="group flex items-start gap-2 text-xs rounded-2xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/5 p-3 text-white/80 transition"
                      >
                        <span className="text-base shrink-0 pt-0.5">{sec?.emoji}</span>
                        <div className="flex-1 min-w-0">
                          <p className="break-words leading-relaxed">{h.text}</p>
                          <span className="text-[10px] text-white/40 font-mono mt-1 block">
                            {formatName(h.name)} • {sec?.name}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => copy(h.text)}
                          className="shrink-0 p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-white/50 hover:text-white transition cursor-pointer"
                          title="Copiar frase"
                        >
                          <Copy className="w-3 h-3" />
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </section>
            )}
          </div>
        ) : (
          <PhraseEditor
            phrases={draft}
            onChange={setDraft}
            onSave={savePhrases}
            hasUnsaved={hasUnsaved}
            storageError={storageError}
          />
        )}
      </main>

      {/* Floating Bottom Navigation */}
      <nav className="fixed bottom-0 inset-x-0 max-w-md mx-auto bg-[#0b0714]/90 backdrop-blur-xl border-t border-white/10 grid grid-cols-2 z-20">
        <button
          type="button"
          onClick={() => setTab('sortear')}
          className={cn(
            'py-3.5 flex flex-col items-center justify-center gap-1 text-xs font-bold transition cursor-pointer',
            tab === 'sortear'
              ? 'text-fuchsia-400 bg-white/[0.04]'
              : 'text-white/40 hover:text-white/70'
          )}
        >
          <Dices className={cn('w-5 h-5', tab === 'sortear' ? 'text-fuchsia-400' : 'text-white/40')} />
          <span>Sortear</span>
        </button>

        <button
          type="button"
          onClick={() => setTab('frases')}
          className={cn(
            'py-3.5 flex flex-col items-center justify-center gap-1 text-xs font-bold transition cursor-pointer',
            tab === 'frases'
              ? 'text-fuchsia-400 bg-white/[0.04]'
              : 'text-white/40 hover:text-white/70'
          )}
        >
          <MessageSquareQuote className={cn('w-5 h-5', tab === 'frases' ? 'text-fuchsia-400' : 'text-white/40')} />
          <span className="relative">
            Frases
            {hasUnsaved && <span className="absolute -top-1 -right-2.5 w-2 h-2 rounded-full bg-amber-400" />}
          </span>
        </button>
      </nav>

      {/* Pop-up do resultado */}
      {showResult && result && resultSector && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center bg-black/75 backdrop-blur-sm animate-fade p-4"
          onClick={closeResult}
        >
          <div
            key={result.id}
            className="w-full max-w-md space-y-3 animate-pop"
            onClick={(e) => e.stopPropagation()}
          >
            <div
              className={cn(
                'rounded-3xl p-5 bg-gradient-to-br shadow-2xl relative overflow-hidden border border-white/20',
                resultSector.color
              )}
            >
              <div className="absolute -top-12 -right-12 w-32 h-32 bg-white/15 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-white/90 mb-3 border-b border-white/20 pb-2">
                <span className="flex items-center gap-1.5">
                  <span className="text-base">{resultSector.emoji}</span>
                  {resultSector.name}
                </span>
                <div className="flex items-center gap-1.5">
                  {result.giftId && (
                    <span className="bg-black/30 px-2 py-0.5 rounded-full text-[11px] font-semibold text-white/90">
                      {GIFTS.find((g) => g.id === result.giftId)?.name}
                    </span>
                  )}
                  <span className="text-[10px] text-white/70 font-mono">{result.timestamp}</span>
                  <button
                    type="button"
                    onClick={closeResult}
                    aria-label="Fechar"
                    className="ml-1 p-1 rounded-full bg-black/30 hover:bg-black/50 active:scale-90 transition cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <p className="text-xl sm:text-2xl font-black leading-snug drop-shadow-md break-words text-white tracking-tight">
                {result.text}
              </p>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => draw(result.name, result.gender, result.giftId)}
                className="rounded-2xl bg-[#181028] hover:bg-[#221538] border border-white/15 py-3 text-xs sm:text-sm font-bold active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer shadow"
              >
                <RotateCw className="w-4 h-4 text-cyan-300" /> Outra
              </button>

              <button
                type="button"
                onClick={() => speak(result.text)}
                className={cn(
                  'rounded-2xl border py-3 text-xs sm:text-sm font-bold active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer shadow',
                  isSpeaking
                    ? 'bg-red-500/30 border-red-400 text-red-200 animate-pulse'
                    : 'bg-[#181028] hover:bg-[#221538] border-white/15 text-white'
                )}
              >
                <Volume2 className={cn('w-4 h-4', isSpeaking ? 'text-red-300' : 'text-fuchsia-300')} />
                {isSpeaking ? 'Parar' : 'Falar'}
              </button>

              <button
                type="button"
                onClick={() => copy(result.text)}
                className={cn(
                  'rounded-2xl border py-3 text-xs sm:text-sm font-bold active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer shadow',
                  copied
                    ? 'bg-emerald-500/30 border-emerald-400 text-emerald-200'
                    : 'bg-[#181028] hover:bg-[#221538] border-white/15 text-white'
                )}
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-300" /> Copiado!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-amber-300" /> Copiar
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Escolher Homem / Mulher */}
      {askGender && (
        <div
          className="fixed inset-0 z-30 flex items-end justify-center bg-black/75 backdrop-blur-sm animate-fade p-2"
          onClick={() => setAskGender(false)}
        >
          <div
            className="w-full max-w-md rounded-3xl bg-[#181028] border border-white/15 p-6 pb-8 shadow-2xl animate-slide-up space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-1.5 rounded-full bg-white/20 mx-auto" />

            <div className="text-center space-y-1">
              <span className="text-[11px] font-bold uppercase tracking-widest text-fuchsia-400">
                Escaneando Participante
              </span>
              <h3 className="text-3xl font-black text-white tracking-tight break-words">
                {formatName(name)}
              </h3>
              {gift && (
                <div className="inline-flex items-center gap-1.5 text-xs text-amber-300 font-semibold bg-white/5 px-3 py-1 rounded-full border border-white/10 mt-1">
                  <span>{gift.emoji}</span>
                  <span>Presente: {gift.name}</span>
                </div>
              )}
            </div>

            <p className="text-center text-sm font-semibold text-white/70 pt-1">
              Selecione o gênero para afinar o tom da zoeira:
            </p>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                type="button"
                onClick={() => pickGender('homem')}
                className="rounded-2xl bg-gradient-to-br from-blue-600 to-cyan-500 hover:brightness-110 py-5 px-3 text-lg font-black active:scale-95 shadow-xl shadow-blue-500/20 transition flex flex-col items-center gap-1 cursor-pointer"
              >
                <span className="text-3xl">👨</span>
                <span>HOMEM</span>
                <span className="text-[10px] font-normal text-white/80">Zoeira Máxima 🔥</span>
              </button>

              <button
                type="button"
                onClick={() => pickGender('mulher')}
                className="rounded-2xl bg-gradient-to-br from-pink-500 to-fuchsia-600 hover:brightness-110 py-5 px-3 text-lg font-black active:scale-95 shadow-xl shadow-fuchsia-500/20 transition flex flex-col items-center gap-1 cursor-pointer"
              >
                <span className="text-3xl">👩</span>
                <span>MULHER</span>
                <span className="text-[10px] font-normal text-white/80">Zoeira de Boa 😏</span>
              </button>
            </div>

            <button
              type="button"
              onClick={() => setAskGender(false)}
              className="w-full text-xs font-semibold text-white/40 hover:text-white/70 py-2 transition cursor-pointer"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
