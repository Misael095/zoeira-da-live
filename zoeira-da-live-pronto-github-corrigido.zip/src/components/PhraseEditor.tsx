import { useRef, useState } from 'react';
import { SECTORS, type SectorId } from '../data';
import { cn } from '../utils/cn';
import {
  Plus,
  Trash2,
  Search,
  Sparkles,
  Save,
  Check,
  Pencil,
  ArrowRightLeft,
  X,
  Download,
  Upload,
} from 'lucide-react';

type Phrases = Record<SectorId, string[]>;

interface Props {
  phrases: Phrases;
  onChange: (p: Phrases) => void;
  onSave: () => void;
  hasUnsaved: boolean;
  storageError: boolean;
}

const norm = (s: string) => s.trim().toLowerCase().replace(/\s+/g, ' ');
const withNome = (t: string) => (/\{nome\}/i.test(t) ? t : `{nome}, ${t}`);

// Cada linha vira uma frase; o ponto final é só pontuação
const parseLines = (text: string) =>
  text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .map(withNome);

export default function PhraseEditor({ phrases, onChange, onSave, hasUnsaved, storageError }: Props) {
  const [active, setActive] = useState<SectorId>('maxima');
  const [text, setText] = useState('');
  const [search, setSearch] = useState('');
  const [justSaved, setJustSaved] = useState(false);
  const [notice, setNotice] = useState('');
  const [editing, setEditing] = useState<{ idx: number; value: string } | null>(null);
  const [movingIdx, setMovingIdx] = useState<number | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const noticeTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const sector = SECTORS.find((s) => s.id === active)!;
  const list = phrases[active] || [];
  const pendingCount = parseLines(text).length;

  const showNotice = (msg: string) => {
    setNotice(msg);
    clearTimeout(noticeTimer.current);
    noticeTimer.current = setTimeout(() => setNotice(''), 4000);
  };

  const resetRowState = () => {
    setEditing(null);
    setMovingIdx(null);
  };

  const add = () => {
    const parsed = parseLines(text);
    if (!parsed.length) return;
    const seen = new Set(list.map(norm));
    const fresh: string[] = [];
    let dup = 0;
    for (const p of parsed) {
      const k = norm(p);
      if (seen.has(k)) {
        dup++;
        continue;
      }
      seen.add(k);
      fresh.push(p);
    }
    if (!fresh.length) {
      showNotice('Essas frases já existem neste setor.');
      return;
    }
    onChange({ ...phrases, [active]: [...fresh, ...list] });
    setText('');
    resetRowState();
    showNotice(
      `${fresh.length} frase${fresh.length > 1 ? 's adicionadas' : ' adicionada'}` +
        (dup ? ` (${dup} repetida${dup > 1 ? 's ignoradas' : ' ignorada'})` : '') +
        '. Toque em Salvar mensagens.'
    );
  };

  const remove = (idx: number) => {
    onChange({ ...phrases, [active]: list.filter((_, i) => i !== idx) });
    resetRowState();
  };

  const saveEdit = () => {
    if (!editing) return;
    const t = editing.value.trim();
    if (!t) return;
    const final = withNome(t);
    const clash = list.some((p, i) => i !== editing.idx && norm(p) === norm(final));
    if (clash) {
      showNotice('Já existe outra frase igual neste setor.');
      return;
    }
    onChange({ ...phrases, [active]: list.map((p, i) => (i === editing.idx ? final : p)) });
    setEditing(null);
  };

  const move = (idx: number, target: SectorId) => {
    const phrase = list[idx];
    const targetList = phrases[target] || [];
    const exists = targetList.some((p) => norm(p) === norm(phrase));
    onChange({
      ...phrases,
      [active]: list.filter((_, i) => i !== idx),
      [target]: exists ? targetList : [phrase, ...targetList],
    });
    resetRowState();
    const tName = SECTORS.find((s) => s.id === target)?.name;
    showNotice(
      exists ? `Já existia em ${tName}; removida deste setor.` : `Frase movida para ${tName}. Toque em Salvar mensagens.`
    );
  };

  const exportBackup = () => {
    const data = {
      app: 'zoeira-da-live',
      version: 1,
      exportedAt: new Date().toISOString(),
      phrases,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `zoeira-frases-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showNotice('Backup exportado.');
  };

  const importBackup = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      const src = data?.phrases ?? data;
      const next: Phrases = { ...phrases };
      let added = 0;
      for (const s of SECTORS) {
        const arr = src?.[s.id];
        if (!Array.isArray(arr)) continue;
        const cur = next[s.id] || [];
        const seen = new Set(cur.map(norm));
        const fresh: string[] = [];
        for (const x of arr) {
          if (typeof x !== 'string') continue;
          const t = x.trim();
          if (!t || seen.has(norm(t))) continue;
          seen.add(norm(t));
          fresh.push(t);
        }
        if (fresh.length) {
          next[s.id] = [...cur, ...fresh];
          added += fresh.length;
        }
      }
      if (!added) {
        showNotice('Nenhuma frase nova encontrada nesse arquivo.');
        return;
      }
      onChange(next);
      resetRowState();
      showNotice(`${added} frase${added > 1 ? 's importadas' : ' importada'}. Toque em Salvar mensagens.`);
    } catch {
      showNotice('Arquivo inválido. Use um backup exportado pelo app.');
    }
  };

  const handleSave = () => {
    onSave();
    setJustSaved(true);
    setTimeout(() => setJustSaved(false), 1800);
  };

  const q = search.trim().toLowerCase();
  const filteredList = list
    .map((p, idx) => ({ p, idx }))
    .filter(({ p }) => !q || p.toLowerCase().includes(q));

  return (
    <div className="space-y-4 pb-8">
      {/* Category Pills */}
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 snap-x no-scrollbar">
        {SECTORS.map((s) => (
          <button
            key={s.id}
            onClick={() => {
              setActive(s.id);
              setSearch('');
              resetRowState();
            }}
            className={cn(
              'snap-start shrink-0 rounded-2xl px-3.5 py-2.5 text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer shadow-sm',
              active === s.id
                ? `bg-gradient-to-r ${s.color} border-transparent text-white shadow-lg shadow-fuchsia-500/20`
                : 'bg-white/5 border-white/10 text-white/70 hover:bg-white/10'
            )}
          >
            <span className="text-base">{s.emoji}</span>
            <span>{s.name}</span>
            <span className="ml-1 text-[11px] opacity-80 px-1.5 py-0.5 rounded-full bg-black/30 font-mono">
              {phrases[s.id]?.length || 0}
            </span>
          </button>
        ))}
      </div>

      {/* Add New Phrase Box */}
      <div className="rounded-3xl bg-white/[0.04] border border-white/10 p-4 space-y-3 backdrop-blur-md shadow-xl">
        <div className="flex items-start gap-2.5">
          <div className="p-2 rounded-xl bg-white/10 text-xl shrink-0">{sector.emoji}</div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5 flex-wrap">
              {sector.name}
              <span className="text-[10px] font-normal text-white/50 bg-white/10 px-2 py-0.5 rounded-full">
                {sector.desc}
              </span>
            </h3>
            <p className="text-xs text-white/60 mt-0.5">
              Uma frase por linha (Enter separa). O{' '}
              <code className="bg-white/15 px-1.5 py-0.5 rounded text-fuchsia-300 font-mono">{'{nome}'}</code>{' '}
              é colocado na frente automaticamente.
            </p>
          </div>
        </div>

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={4}
          placeholder={'Uma frase por linha.\nEx: manda áudio de 7 minutos pra falar oi.\nOutra frase aqui.'}
          className="w-full rounded-2xl bg-black/40 border border-white/10 p-3.5 text-sm sm:text-base outline-none focus:border-fuchsia-400/80 focus:ring-1 focus:ring-fuchsia-400/50 resize-none placeholder:text-white/25 transition"
        />

        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setText((t) => (t.trim() ? t + ' {nome}' : '{nome}, '))}
            className="rounded-xl bg-white/10 hover:bg-white/15 px-3 py-2 text-xs font-semibold text-white/90 active:scale-95 transition flex items-center gap-1 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-fuchsia-400" /> + {'{nome}'}
          </button>
          <button
            type="button"
            onClick={add}
            disabled={!pendingCount}
            className={cn(
              'flex-1 rounded-xl py-2 px-4 text-xs font-bold text-white shadow-md active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer',
              pendingCount
                ? `bg-gradient-to-r ${sector.color} hover:brightness-110`
                : 'bg-white/10 text-white/40 cursor-not-allowed'
            )}
          >
            <Plus className="w-4 h-4" />
            {pendingCount > 1 ? `Adicionar ${pendingCount} frases` : 'Adicionar frase'}
          </button>
        </div>
      </div>

      {notice && (
        <p className="text-center text-[11px] text-cyan-200 bg-cyan-500/10 border border-cyan-400/20 rounded-xl py-2 px-3">
          {notice}
        </p>
      )}

      {/* Search Phrases */}
      {list.length > 4 && (
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-white/40" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={`Buscar entre as ${list.length} frases deste setor...`}
            className="w-full rounded-2xl bg-white/5 border border-white/10 pl-10 pr-4 py-2.5 text-xs text-white placeholder:text-white/30 outline-none focus:border-fuchsia-400 transition"
          />
        </div>
      )}

      {/* Phrases List */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-white/50 px-1">
          <span>
            {filteredList.length} frase{filteredList.length !== 1 ? 's' : ''} cadastrada
            {filteredList.length !== 1 ? 's' : ''}
            <span className="text-white/30"> • toque na frase para editar</span>
          </span>
          {search && (
            <button onClick={() => setSearch('')} className="text-fuchsia-300 hover:underline">
              limpar filtro
            </button>
          )}
        </div>

        <ul className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
          {filteredList.length === 0 ? (
            <li className="text-center text-white/40 text-xs py-8 bg-white/[0.02] rounded-2xl border border-dashed border-white/10">
              {search
                ? 'Nenhuma frase encontrada com esse termo.'
                : 'Nenhuma frase cadastrada neste setor. Adicione a primeira acima!'}
            </li>
          ) : (
            filteredList.map(({ p, idx }) => (
              <li
                key={`${active}-${idx}`}
                className="rounded-2xl bg-white/[0.04] hover:bg-white/[0.07] border border-white/10 p-3 transition space-y-2"
              >
                {editing?.idx === idx ? (
                  <div className="space-y-2">
                    <textarea
                      autoFocus
                      value={editing.value}
                      onChange={(e) => setEditing({ idx, value: e.target.value })}
                      rows={3}
                      className="w-full rounded-xl bg-black/40 border border-fuchsia-400/60 p-2.5 text-sm outline-none resize-none"
                    />
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={saveEdit}
                        className="flex-1 rounded-xl bg-emerald-500/25 hover:bg-emerald-500/35 text-emerald-200 py-2 text-xs font-bold active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" /> OK
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditing(null)}
                        className="flex-1 rounded-xl bg-white/10 hover:bg-white/15 text-white/80 py-2 text-xs font-bold active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" /> Cancelar
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex gap-2.5 items-start">
                    <span className="text-[11px] font-mono text-white/30 pt-0.5 select-none">#{idx + 1}</span>
                    <p
                      onClick={() => {
                        setMovingIdx(null);
                        setEditing({ idx, value: p });
                      }}
                      className="flex-1 text-xs sm:text-sm leading-relaxed text-white/90 break-words cursor-pointer"
                    >
                      {p}
                    </p>
                    <div className="shrink-0 flex gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          setMovingIdx(null);
                          setEditing({ idx, value: p });
                        }}
                        className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-white/60 active:scale-90 transition cursor-pointer"
                        title="Editar frase"
                        aria-label="Editar frase"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setEditing(null);
                          setMovingIdx(movingIdx === idx ? null : idx);
                        }}
                        className={cn(
                          'p-1.5 rounded-lg active:scale-90 transition cursor-pointer',
                          movingIdx === idx
                            ? 'bg-cyan-500/30 text-cyan-200'
                            : 'bg-white/5 hover:bg-white/15 text-cyan-300/80'
                        )}
                        title="Mover para outro setor"
                        aria-label="Mover para outro setor"
                      >
                        <ArrowRightLeft className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => remove(idx)}
                        className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/25 text-red-300 active:scale-90 transition cursor-pointer"
                        title="Apagar frase"
                        aria-label="Apagar frase"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}

                {movingIdx === idx && (
                  <div className="pt-2 border-t border-white/10 space-y-1.5">
                    <p className="text-[10px] uppercase font-bold tracking-wider text-white/40">Mover para:</p>
                    <div className="flex flex-wrap gap-1.5">
                      {SECTORS.filter((s) => s.id !== active).map((s) => (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => move(idx, s.id)}
                          className="rounded-full bg-white/10 hover:bg-white/20 border border-white/10 px-2.5 py-1 text-[11px] font-semibold flex items-center gap-1 active:scale-95 transition cursor-pointer"
                        >
                          <span>{s.emoji}</span>
                          {s.name}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </li>
            ))
          )}
        </ul>
      </div>

      {/* Backup */}
      <div className="rounded-3xl bg-white/[0.03] border border-white/10 p-4 space-y-2.5">
        <div>
          <h3 className="text-[11px] uppercase tracking-wider text-white/60 font-bold">Backup das frases</h3>
          <p className="text-[11px] text-white/40 mt-0.5">
            As frases ficam só neste navegador. Exporte um arquivo para guardar ou levar para outro celular.
            Ao importar, as frases novas são somadas às que você já tem.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={exportBackup}
            className="rounded-2xl bg-white/10 hover:bg-white/15 border border-white/10 py-2.5 text-xs font-bold active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Download className="w-4 h-4 text-cyan-300" /> Exportar
          </button>
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="rounded-2xl bg-white/10 hover:bg-white/15 border border-white/10 py-2.5 text-xs font-bold active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Upload className="w-4 h-4 text-amber-300" /> Importar
          </button>
        </div>
        <input ref={fileRef} type="file" accept=".json,application/json" onChange={importBackup} className="hidden" />
      </div>

      {/* Save Button */}
      <div className="sticky bottom-[72px] z-10 pt-2 space-y-1.5">
        {storageError && (
          <p className="text-center text-[11px] text-red-300 bg-red-500/10 border border-red-500/30 rounded-xl py-1.5 px-2">
            Sem espaço no navegador para salvar tudo. Apague algumas frases.
          </p>
        )}
        <button
          type="button"
          onClick={handleSave}
          disabled={!hasUnsaved}
          className={cn(
            'w-full rounded-2xl py-3.5 text-sm font-black active:scale-[0.98] transition flex items-center justify-center gap-2 shadow-xl',
            hasUnsaved
              ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-white cursor-pointer animate-pulse'
              : justSaved
                ? 'bg-emerald-500/20 border border-emerald-400/40 text-emerald-200'
                : 'bg-[#181028] border border-white/10 text-white/40 cursor-not-allowed'
          )}
        >
          {hasUnsaved ? (
            <>
              <Save className="w-4 h-4" /> Salvar mensagens
            </>
          ) : (
            <>
              <Check className="w-4 h-4" /> {justSaved ? 'Mensagens salvas!' : 'Tudo salvo'}
            </>
          )}
        </button>
      </div>
    </div>
  );
}
