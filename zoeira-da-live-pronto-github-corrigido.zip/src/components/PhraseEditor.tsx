import { useState } from 'react';
import { SECTORS, type SectorId } from '../data';
import { cn } from '../utils/cn';
import { Plus, Trash2, Search, Sparkles, Save, Check } from 'lucide-react';

interface Props {
  phrases: Record<SectorId, string[]>;
  onChange: (p: Record<SectorId, string[]>) => void;
  onSave: () => void;
  hasUnsaved: boolean;
  storageError: boolean;
}

export default function PhraseEditor({ phrases, onChange, onSave, hasUnsaved, storageError }: Props) {
  const [active, setActive] = useState<SectorId>('maxima');
  const [text, setText] = useState('');
  const [search, setSearch] = useState('');
  const [justSaved, setJustSaved] = useState(false);
  const sector = SECTORS.find((s) => s.id === active)!;
  const list = phrases[active] || [];

  const add = () => {
    const t = text.trim();
    if (!t) return;
    const final = t.includes('{nome}') ? t : `{nome}, ${t}`;
    onChange({ ...phrases, [active]: [final, ...list] });
    setText('');
  };

  const remove = (indexInFiltered: number, originalPhrase: string) => {
    onChange({
      ...phrases,
      [active]: list.filter((p, idx) => {
        if (search) {
          return p !== originalPhrase || idx !== list.indexOf(originalPhrase);
        }
        return idx !== indexInFiltered;
      }),
    });
  };

  const handleSave = () => {
    onSave();
    setJustSaved(true);
    setTimeout(() => setJustSaved(false), 1800);
  };

  const filteredList = search.trim()
    ? list.filter((p) => p.toLowerCase().includes(search.toLowerCase()))
    : list;

  return (
    <div className="space-y-4 pb-8">
      {/* Category Pills */}
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 snap-x no-scrollbar">
        {SECTORS.map((s) => (
          <button
            key={s.id}
            onClick={() => {
              setActive(s.id);
              setSearch('');
            }}
            className={cn(
              'snap-start shrink-0 rounded-2xl px-3.5 py-2.5 text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer shadow-sm',
              active === s.id
                ? `bg-gradient-to-r ${s.color} border-transparent text-white shadow-lg shadow-fuchsia-500/20`
                : 'bg-white/5 border-white/10 text-white/70 hover:bg-white/10'
            )}
          >
            <span className="text-base">{s.emoji}</span>
            <span>{s.name}</span>
            <span className="ml-1 text-[11px] opacity-80 px-1.5 py-0.5 rounded-full bg-black/30 font-mono">
              {phrases[s.id]?.length || 0}
            </span>
          </button>
        ))}
      </div>

      {/* Add New Phrase Box */}
      <div className="rounded-3xl bg-white/[0.04] border border-white/10 p-4 space-y-3 backdrop-blur-md shadow-xl">
        <div className="flex items-start gap-2.5">
          <div className="p-2 rounded-xl bg-white/10 text-xl shrink-0">
            {sector.emoji}
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              {sector.name}
              <span className="text-[10px] font-normal text-white/50 bg-white/10 px-2 py-0.5 rounded-full">
                {sector.desc}
              </span>
            </h3>
            <p className="text-xs text-white/60 mt-0.5">
              Use a tag <code className="bg-white/15 px-1.5 py-0.5 rounded text-fuchsia-300 font-mono">{'{nome}'}</code> onde o nome da pessoa vai aparecer.
            </p>
          </div>
        </div>

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={3}
          placeholder="Ex: manda áudio de 7 minutos pra falar 'oi'..."
          className="w-full rounded-2xl bg-black/40 border border-white/10 p-3.5 text-sm sm:text-base outline-none focus:border-fuchsia-400/80 focus:ring-1 focus:ring-fuchsia-400/50 resize-none placeholder:text-white/25 transition"
        />

        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setText((t) => (t.trim() ? t + ' {nome}' : '{nome}, '))}
            className="rounded-xl bg-white/10 hover:bg-white/15 px-3 py-2 text-xs font-semibold text-white/90 active:scale-95 transition flex items-center gap-1 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-fuchsia-400" /> + {'{nome}'}
          </button>
          <button
            type="button"
            onClick={add}
            disabled={!text.trim()}
            className={cn(
              'flex-1 rounded-xl py-2 px-4 text-xs font-bold text-white shadow-md active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer',
              text.trim()
                ? `bg-gradient-to-r ${sector.color} hover:brightness-110`
                : 'bg-white/10 text-white/40 cursor-not-allowed'
            )}
          >
            <Plus className="w-4 h-4" /> Adicionar frase
          </button>
        </div>
      </div>

      {/* Search Phrases */}
      {list.length > 4 && (
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-white/40" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={`Buscar entre as ${list.length} frases deste setor...`}
            className="w-full rounded-2xl bg-white/5 border border-white/10 pl-10 pr-4 py-2.5 text-xs text-white placeholder:text-white/30 outline-none focus:border-fuchsia-400 transition"
          />
        </div>
      )}

      {/* Phrases List */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-white/50 px-1">
          <span>{filteredList.length} frase{filteredList.length !== 1 ? 's' : ''} cadastrada{filteredList.length !== 1 ? 's' : ''}</span>
          {search && (
            <button
              onClick={() => setSearch('')}
              className="text-fuchsia-300 hover:underline"
            >
              limpar filtro
            </button>
          )}
        </div>

        <ul className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
          {filteredList.length === 0 ? (
            <li className="text-center text-white/40 text-xs py-8 bg-white/[0.02] rounded-2xl border border-dashed border-white/10">
              {search
                ? 'Nenhuma frase encontrada com esse termo.'
                : 'Nenhuma frase cadastrada neste setor. Adicione a primeira acima!'}
            </li>
          ) : (
            filteredList.map((p, i) => (
              <li
                key={i}
                className="group flex gap-2.5 items-start rounded-2xl bg-white/[0.04] hover:bg-white/[0.07] border border-white/10 p-3 transition"
              >
                <span className="text-[11px] font-mono text-white/30 pt-0.5 select-none">
                  #{i + 1}
                </span>
                <p className="flex-1 text-xs sm:text-sm leading-relaxed text-white/90 break-words">
                  {p}
                </p>
                <button
                  type="button"
                  onClick={() => remove(i, p)}
                  className="shrink-0 p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/25 text-red-300 active:scale-90 transition cursor-pointer"
                  title="Apagar frase"
                  aria-label="Apagar frase"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </li>
            ))
          )}
        </ul>
      </div>

      {/* Save Button */}
      <div className="sticky bottom-[72px] z-10 pt-2 space-y-1.5">
        {storageError && (
          <p className="text-center text-[11px] text-red-300 bg-red-500/10 border border-red-500/30 rounded-xl py-1.5 px-2">
            Sem espaço no navegador para salvar tudo. Apague algumas frases.
          </p>
        )}
        <button
          type="button"
          onClick={handleSave}
          disabled={!hasUnsaved}
          className={cn(
            'w-full rounded-2xl py-3.5 text-sm font-black active:scale-[0.98] transition flex items-center justify-center gap-2 shadow-xl',
            hasUnsaved
              ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-white cursor-pointer animate-pulse'
              : justSaved
                ? 'bg-emerald-500/20 border border-emerald-400/40 text-emerald-200'
                : 'bg-[#181028] border border-white/10 text-white/40 cursor-not-allowed'
          )}
        >
          {hasUnsaved ? (
            <><Save className="w-4 h-4" /> Salvar mensagens</>
          ) : (
            <><Check className="w-4 h-4" /> {justSaved ? 'Mensagens salvas!' : 'Tudo salvo'}</>
          )}
        </button>
      </div>
    </div>
  );
}
