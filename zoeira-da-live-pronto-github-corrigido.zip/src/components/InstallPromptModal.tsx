import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import {
  Download,
  Share2,
  PlusSquare,
  Smartphone,
  CheckCircle2,
  Copy,
  Check,
  X,
  ExternalLink,
  QrCode as QrCodeIcon,
  Sparkles
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export default function InstallPromptModal({ isOpen, onClose }: Props) {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const [copiedLink, setCopiedLink] = useState(false);
  const [activeTab, setActiveTab] = useState<'auto' | 'android' | 'ios' | 'qr'>(() => {
    if (isIOS) return 'ios';
    if (isAndroid) return 'android';
    return 'auto';
  });

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';

  useEffect(() => {
    if (isOpen && currentUrl) {
      QRCode.toDataURL(currentUrl, {
        width: 280,
        margin: 2,
        color: {
          dark: '#0b0714',
          light: '#ffffff',
        },
      })
        .then(setQrCodeUrl)
        .catch(console.error);
    }
  }, [isOpen, currentUrl]);

  if (!isOpen) return null;

  const copyUrl = async () => {
    try {
      await navigator.clipboard.writeText(currentUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } catch {
      /* ignore */
    }
  };

  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-3xl bg-[#150d26] border border-white/15 p-6 shadow-2xl animate-pop relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow behind */}
        <div className="absolute -top-20 -right-20 w-44 h-44 bg-fuchsia-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/5 hover:bg-white/10 text-white/50 hover:text-white transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="text-center space-y-1.5 pb-2">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-fuchsia-600 to-cyan-500 p-0.5 mx-auto shadow-lg shadow-fuchsia-500/25 flex items-center justify-center">
            <div className="w-full h-full bg-[#0b0714] rounded-2xl flex items-center justify-center">
              <Smartphone className="w-7 h-7 text-cyan-300" />
            </div>
          </div>

          <h3 className="text-xl font-black text-white tracking-tight">
            Instalar no Celular
          </h3>
          <p className="text-xs text-white/60">
            Acesse direto da tela inicial como um app nativo, sem barras de navegador e super rápido!
          </p>
        </div>

        {/* Device Switcher Tabs */}
        <div className="grid grid-cols-3 gap-1 p-1 bg-white/5 rounded-2xl border border-white/10 my-3 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('android')}
            className={`py-2 rounded-xl transition cursor-pointer ${
              activeTab === 'android' || (activeTab === 'auto' && !isIOS)
                ? 'bg-fuchsia-600 text-white shadow'
                : 'text-white/60 hover:text-white'
            }`}
          >
            🤖 Android
          </button>
          <button
            onClick={() => setActiveTab('ios')}
            className={`py-2 rounded-xl transition cursor-pointer ${
              activeTab === 'ios' || (activeTab === 'auto' && isIOS)
                ? 'bg-fuchsia-600 text-white shadow'
                : 'text-white/60 hover:text-white'
            }`}
          >
            🍏 iPhone / iOS
          </button>
          <button
            onClick={() => setActiveTab('qr')}
            className={`py-2 rounded-xl transition cursor-pointer flex items-center justify-center gap-1 ${
              activeTab === 'qr'
                ? 'bg-fuchsia-600 text-white shadow'
                : 'text-white/60 hover:text-white'
            }`}
          >
            <QrCodeIcon className="w-3.5 h-3.5" /> QR Code
          </button>
        </div>

        {/* Already Installed Check */}
        {isInstalled && (
          <div className="rounded-2xl bg-emerald-500/20 border border-emerald-500/40 p-3 text-center text-xs text-emerald-200 mb-3 flex items-center justify-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-300" />
            Este app já está instalado no seu dispositivo!
          </div>
        )}

        {/* TAB 1: Android Flow */}
        {(activeTab === 'android' || (activeTab === 'auto' && !isIOS)) && (
          <div className="space-y-3">
            {isInstallable ? (
              <button
                onClick={handleInstallClick}
                className="w-full rounded-2xl bg-gradient-to-r from-cyan-500 via-fuchsia-500 to-pink-500 py-3.5 px-4 font-black text-sm text-white shadow-xl shadow-fuchsia-500/30 hover:brightness-110 active:scale-[0.98] transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                INSTALAR AGORA NO ANDROID
              </button>
            ) : (
              <div className="rounded-2xl bg-white/[0.04] border border-white/10 p-3.5 space-y-2 text-xs">
                <p className="font-bold text-white flex items-center gap-1.5 text-fuchsia-300">
                  <Sparkles className="w-3.5 h-3.5" /> No Google Chrome do Android:
                </p>
                <ol className="space-y-2 text-white/80 list-decimal list-inside leading-relaxed">
                  <li>
                    Toque nos <strong>3 pontinhos (⋮)</strong> no canto superior direito do Chrome.
                  </li>
                  <li>
                    Toque em <strong>"Instalar aplicativo"</strong> (ou <em>"Adicionar à tela inicial"</em>).
                  </li>
                  <li>
                    Confirme em <strong>"Instalar"</strong>.
                  </li>
                </ol>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: iOS Flow */}
        {(activeTab === 'ios' || (activeTab === 'auto' && isIOS)) && (
          <div className="rounded-2xl bg-white/[0.04] border border-white/10 p-3.5 space-y-2.5 text-xs">
            <p className="font-bold text-white flex items-center gap-1.5 text-pink-300">
              <Share2 className="w-3.5 h-3.5" /> No Safari do iPhone / iPad:
            </p>
            <ol className="space-y-2 text-white/80 leading-relaxed">
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-pink-500/20 text-pink-300 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">1</span>
                <span>Toque no botão <strong>Compartilhar</strong> (ícone com quadrado e seta para cima ⎋) na barra inferior do Safari.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-pink-500/20 text-pink-300 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">2</span>
                <span>Role a lista para baixo e toque em <strong>"Adicionar à Tela de Início"</strong> <PlusSquare className="w-3.5 h-3.5 inline text-white/90" />.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-pink-500/20 text-pink-300 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">3</span>
                <span>Toque em <strong>"Adicionar"</strong> no canto superior direito para finalizar!</span>
              </li>
            </ol>
          </div>
        )}

        {/* TAB 3: QR Code (if on computer) */}
        {activeTab === 'qr' && (
          <div className="space-y-3 text-center">
            {qrCodeUrl ? (
              <div className="bg-white p-3 rounded-2xl w-fit mx-auto shadow-md">
                <img
                  src={qrCodeUrl}
                  alt="QR Code para instalar no celular"
                  className="w-48 h-48 mx-auto"
                />
              </div>
            ) : (
              <div className="w-48 h-48 bg-white/10 rounded-2xl mx-auto flex items-center justify-center text-xs text-white/40">
                Gerando QR Code...
              </div>
            )}
            <p className="text-[11px] text-white/60">
              Aponte a câmera do celular para este QR Code para abrir o app diretamente no seu aparelho.
            </p>
          </div>
        )}

        {/* Share / Copy Link footer */}
        <div className="mt-4 pt-3 border-t border-white/10 flex items-center gap-2">
          <button
            onClick={copyUrl}
            className="flex-1 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 py-2.5 px-3 text-xs font-semibold text-white/80 active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer"
          >
            {copiedLink ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" /> Link Copiado!
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-fuchsia-400" /> Copiar Link do App
              </>
            )}
          </button>

          <button
            onClick={onClose}
            className="rounded-xl bg-white/10 hover:bg-white/15 px-4 py-2.5 text-xs font-semibold text-white/70 active:scale-95 transition cursor-pointer"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}
